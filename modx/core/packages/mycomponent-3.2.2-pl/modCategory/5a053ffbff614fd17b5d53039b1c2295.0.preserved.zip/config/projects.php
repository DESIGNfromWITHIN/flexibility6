<?php

  $projects = array (
  'example' => 'E:/Projects/localhost/flexibility5/modx/assets//mycomponents/mycomponent/_build/config/example.config.php',
  'flexibility5' => 'E:/Projects/localhost/flexibility5/modx/core/components/mycomponent/_build/config/flexibility5.config.php',
  'flexibility6' => 'E:/Projects/localhost/flexibility6/modx/core/components/mycomponent/_build/config/flexibility6.config.php',
);
 return $projects;
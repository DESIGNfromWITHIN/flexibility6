<?php
$cats = array (
  0 => 'MyComponent',
);
return $cats;

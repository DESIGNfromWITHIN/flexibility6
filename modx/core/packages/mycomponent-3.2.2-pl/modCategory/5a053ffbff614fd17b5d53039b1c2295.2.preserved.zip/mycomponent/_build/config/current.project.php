<?php
/** MyComponent Current Project
 *  Change this file whenever you work on another project
 *
 *  This should be set to the lowercase name of your package and
 *  Should match the $packageNameLower value in the Project Config
 *  file (which must be named {packageNameLower}.config.php)
 * */

$currentProject = 'flexibility6';

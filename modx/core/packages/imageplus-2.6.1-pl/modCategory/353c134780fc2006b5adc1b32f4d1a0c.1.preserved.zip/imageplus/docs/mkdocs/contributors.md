The Image+ project was started in 2012 by [Alan Pich](https://github.com/alanpich) and is maintained and developed further since 2015 by [Thomas Jakobi](https://github.com/jako).

Many thanks to everyone else who has contributed to this project:

* [@thomasd](https://github.com/thomasd)
* [@em-piguet](https://github.com/empiguet)
* [@tillilab](https://github.com/tillilab)
* [@FlyGenring](https://github.com/FlyGenring)
* Kristof Kotai
* [@Alroniks](https://github.com/alroniks)
* [@rtripault](https://github.com/rtripault)
* [@TheBoxer](https://github.com/TheBoxer)
* [@KristianP](https://github.com/KristianP)
* [@silentworks](https://github.com/silentworks)
* Nico Telfer
* [@inreti](https://github.com/inreti)
* [@jcdm](https://github.com/jcdm)
* [@Bruno17](https://github.com/Bruno17)

Translations on Crowdin by:
* [@alroniks](https://crowdin.com/profile/alroniks)
* [@AmaZili](https://crowdin.com/profile/AmaZili)
* [@Bartholomej](https://crowdin.com/profile/Bartholomej)
* [@dannevang](https://crowdin.com/profile/dannevang)
* [@gljoslin1014](https://crowdin.com/profile/gljoslin1014)
* [@mac_aronie](https://crowdin.com/profile/mac_aronie)
* [@modmore](https://crowdin.com/profile/modmore)
* [@serimarda](https://crowdin.com/profile/serimarda)
* [@krismas](https://crowdin.com/profile/krismas)

<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//piwik.partout.info/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', 13]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//piwik.partout.info/piwik.php?idsite=13" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->

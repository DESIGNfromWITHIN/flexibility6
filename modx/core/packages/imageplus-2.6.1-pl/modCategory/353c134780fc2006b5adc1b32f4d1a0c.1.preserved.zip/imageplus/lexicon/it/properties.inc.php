<?php

/** Snippet properties */
$_lang['imageplus.imageplus.tvname'] = 'Nome della TV dell\'Image+.';
$_lang['imageplus.imageplus.docid'] = 'La Resource da dove il valore della Image+ TV viene richiamato.';
$_lang['imageplus.imageplus.type'] = 'Tipo della snippet output. Può essere fissato come <i>check</i> <i>tpl</i> ed <i>thumb</i>.';
$_lang['imageplus.imageplus.options'] = 'Opzioni estesi del phpThumb per l\'immagine.';
$_lang['imageplus.imageplus.tpl'] = 'Template chunk per la snippet output.';
$_lang['imageplus.imageplus.value'] = 'Utilizza il suo contenuto codificato in JSON per la snippet output. Le proprietà <i>tvname</i> ed <i>docid</i> vengono ignorati.';
<?php

$config = $modx->migx->customconfigs;

$reqConfigs = $modx->getOption('reqConfigs',$_REQUEST);
$configs = $modx->getOption('configs',$_REQUEST);

$prefix = isset($config['prefix']) && !empty($config['prefix']) ? $config['prefix'] : null;
if (isset($config['use_custom_prefix']) && !empty($config['use_custom_prefix'])) {
    $prefix = isset($config['prefix']) ? $config['prefix'] : '';
}

if (!empty($config['packageName'])) {
    $packageNames = explode(',', $config['packageName']);

    if (count($packageNames) == '1') {
        //for now connecting also to foreign databases, only with one package by default possible
        $xpdo = $modx->migx->getXpdoInstanceAndAddPackage($config);
    } else {
        //all packages must have the same prefix for now!
        foreach ($packageNames as $packageName) {
            $packagepath = $modx->getOption('core_path') . 'components/' . $packageName . '/';
            $modelpath = $packagepath . 'model/';
            if (is_dir($modelpath)) {
                $modx->addPackage($packageName, $modelpath, $prefix);
            }

        }
        $xpdo = &$modx;
    }
}else{
    $xpdo = &$modx;    
}
$classname = $config['classname'];

$tablename = $xpdo->getTableName($classname);

$maxdate = strftime ('%Y-%m-%d %H:%M:%S',time() - (360 * 24 * 60 * 60));

//echo "update {$tablename} set deleted=1 where createdon < '{$maxdate}'";

$xpdo->exec("delete from {$tablename} where deleted = 1");

return $modx->error->success();
<?php
require_once dirname(dirname(__FILE__)) . '/import.class.php';
/**
 * Class cgSettingImportProcessor
 */
class cgSettingImportProcessor extends ClientConfigImportProcessor
{
    public $classKey = 'cgSetting';
}

return 'cgSettingImportProcessor';
